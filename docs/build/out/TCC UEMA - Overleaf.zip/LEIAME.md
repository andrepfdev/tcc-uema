# TCC UEMA — projeto Overleaf

1. No Overleaf: **New Project → Upload Project** e envie o `.zip`.
2. **Menu → Compiler: XeLaTeX** (o `latexmkrc` já pede XeLaTeX; LuaLaTeX também serve). Documento principal: `main.tex`.
3. Compile **duas vezes** (sumário, listas e referências cruzadas de página).

Fonte do texto: `TeX Gyre Termes` (equivalente ao Times New Roman). Placeholders pendentes: agradecimentos e examinadores 1 e 2 (`docs/build/frontmatter.json`).
Arquivo gerado por `docs/build/build-latex.py` — edite os `.md`/`frontmatter.json` e gere de novo.
